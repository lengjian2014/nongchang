INSERT INTO `thinkox_menu` ( `title`, `pid`, `sort`, `url`, `hide`, `tip`, `group`, `is_dev`) VALUES
( '模块管理', 43, 0, 'module/lists', 0, '', '云平台', 0),
('卸载模块', 43, 0, 'module/uninstall', 1, '', '云平台', 0),
( '模块安装', 43, 0, 'module/install', 1, '', '云平台', 0);

CREATE TABLE IF NOT EXISTS `thinkox_module` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL COMMENT '模块名',
  `alias` varchar(30) NOT NULL COMMENT '中文名',
  `version` varchar(20) NOT NULL COMMENT '版本号',
  `is_com` tinyint(4) NOT NULL COMMENT '是否商业版',
  `show_nav` tinyint(4) NOT NULL COMMENT '是否显示在导航栏中',
  `summary` varchar(200) NOT NULL COMMENT '简介',
  `developer` varchar(50) NOT NULL COMMENT '开发者',
  `website` varchar(200) NOT NULL COMMENT '网址',
  `entry` varchar(50) NOT NULL COMMENT '前台入口',
  `is_setup` tinyint(4) NOT NULL DEFAULT '1' COMMENT '是否已安装',
  `sort` int(11) NOT NULL COMMENT '模块排序',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `name_2` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='模块管理表' AUTO_INCREMENT=21 ;
INSERT INTO `thinkox_module` ( `name`, `alias`, `version`, `is_com`, `show_nav`, `summary`, `developer`, `website`, `entry`, `is_setup`, `sort`) VALUES
( 'Blog', '资讯', '1.0.0', 0, 1, '原OneThink的内容模块，ThinkOX实现了前台界面，传统的CMS模块', '上海顶想信息科技有限公司', 'http://www.topthink.net/', 'Blog/index/index', 1, 0),
( 'Event', '活动', '1.0.0', 0, 1, '活动模块，用户可以发起活动', '嘉兴想天信息科技有限公司', 'http://www.ourstu.com', 'Event/index/index', 1, 0),
( 'Forum', '论坛', '1.0.0', 0, 1, '论坛模块，比较简单的论坛模块', '嘉兴想天信息科技有限公司', 'http://www.ourstu.com', 'Forum/index/index', 1, 0),
( 'Group', '群组', '1.0.0', 0, 1, '群组模块，允许用户建立自己的圈子', '嘉兴想天信息科技有限公司', 'http://www.ourstu.com', 'Group/index/index', 1, 0),
( 'Home', '网站主页模块', '1.0.0', 0, 1, '首页模块，主要用于展示网站内容', '嘉兴想天信息科技有限公司', 'http://www.ourstu.com', 'Home/index/index', 1, 0),
( 'Issue', '专辑', '1.0.0', 0, 1, '专辑模块，适用于精品内容展示', '嘉兴想天信息科技有限公司', 'http://www.ourstu.com', 'Issue/index/index', 1, 0),
( 'People', '会员展示', '1.0.0', 0, 1, '会员展示模块，可以用于会员的查找', '嘉兴想天信息科技有限公司', 'http://www.ourstu.com', 'People/index/index', 1, 0),
( 'Shop', '积分商城', '1.0.0', 0, 1, '积分商城模块，用户可以使用积分兑换商品', '嘉兴想天信息科技有限公司', 'http://www.ourstu.com', 'Shop/index/index', 1, 0),
( 'Weibo', '微博', '1.0.0', 0, 1, '微博模块，用户可以发布微博', '嘉兴想天信息科技有限公司', 'http://www.ourstu.com', 'Weibo/index/index', 1, 0);


/*修改等级设置为基础设置*/
UPDATE  `thinkox_menu` SET  `title` =  '基础设置',
`url` =  'User/config' WHERE  `thinkox_menu`.`url` ='User/level';
/*修改用户组名称*/
UPDATE  `thinkox_auth_group` SET  `title` =  '普通用户' WHERE  `thinkox_auth_group`.`id` =1;

/*菜单*/
INSERT INTO `thinkox_menu` (`title`, `pid`, `sort`, `url`, `hide`, `tip`, `group`, `is_dev`) VALUES
( '新增权限节点', 27, 0, 'AuthManager/addNode', 1, '', '', 1),
( '前台权限管理', 27, 0, 'AuthManager/accessUser', 1, '', '权限管理', 0),
( '转移用户组', 16, 0, 'User/changeGroup', 1, '批量转移用户组', '', 0),
( '删除权限节点', 27, 0, 'AuthManager/deleteNode', 1, '', '', 0);


/*权限*/
INSERT INTO `thinkox_auth_rule` ( `module`, `type`, `name`, `title`, `status`, `condition`) VALUES
( 'Weibo', 1, 'sendWeibo', '发微博', 1, ''),
( 'Weibo', 1, 'deleteWeibo', '删除微博', 1, ''),
( 'Weibo', 1, 'setWeiboTop', '微博置顶', 1, ''),
( 'Weibo', 1, 'beTopicAdmin', '抢先成为话题主持人', 1, ''),
( 'Weibo', 1, 'manageTopic', '管理话题', 1, ''),
( 'Home', 1, 'deleteLocalComment', '删除本地评论', 1, ''),
( 'Issue', 1, 'addIssueContent', '专辑投稿权限', 1, ''),
( 'Issue', 1, 'editIssueContent', '编辑专辑内容（管理）', 1, '');


/*钩子*/
INSERT INTO `thinkox_hooks` ( `name`, `description`, `type`, `update_time`, `addons`) VALUES
( 'userConfig', '用户配置页面钩子', 1, 1417137557, 'SyncLogin'),
( 'weiboSide', '微博侧边钩子', 1, 1417063425, 'Retopic'),
( 'personalMenus', '顶部导航栏个人下拉菜单', 1, 1417146501, '');


ALTER TABLE  `thinkox_group_type` ADD  `pid` INT NOT NULL;

INSERT INTO `thinkox_hooks` ( `name`, `description`, `type`, `update_time`) VALUES
( 'dealPicture', '上传图片处理', 2, 1417139975);


DELETE FROM `thinkox_config` WHERE `thinkox_config`.`name` = '_EXPRESSION_EXPRESSION';
DELETE FROM `thinkox_menu` WHERE `thinkox_menu`.`group` = '表情配置';

INSERT INTO `thinkox_menu` (`title`, `pid`, `sort`, `url`, `hide`, `tip`, `group`, `is_dev`) VALUES
( '表情管理', 68, 30, 'admin/expression/index', 0, '', '表情配置', 0),
( '表情列表', 68, 0, 'admin/expression/expressionList', 1, '', '表情配置', 0),
( '新增表情包', 68, 0, 'adimn/expression/add', 1, '', '表情配置', 0);


INSERT INTO `thinkox_config` (`name`, `type`, `title`, `group`, `extra`, `remark`, `create_time`, `update_time`, `status`, `value`, `sort`) VALUES
( '_EXPRESSION_EXPRESSION', 0, '', 0, '', '', 1417150390, 1417150390, 1, 'miniblog', 0);



INSERT INTO `thinkox_hooks` ( `name`, `description`, `type`, `update_time`, `addons`) VALUES
( 'ucenterSideMenu', '用户中心左侧菜单', 1, 1417161205, '');
ALTER TABLE  `thinkox_forum` ADD  `background` INT NOT NULL;
ALTER TABLE  `thinkox_forum` ADD  `description` VARCHAR( 5000 ) NOT NULL;
ALTER TABLE  `thinkox_forum` ADD  `admin` VARCHAR( 100 ) NOT NULL;
ALTER TABLE  `thinkox_forum` ADD  `type_id` INT NOT NULL;
CREATE TABLE IF NOT EXISTS `thinkox_forum_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL COMMENT '标题',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `sort` int(11) NOT NULL,
  `pid` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='论坛分类表' AUTO_INCREMENT=3 ;

INSERT INTO `thinkox_forum_type` (`id`, `title`, `status`, `sort`, `pid`) VALUES
(1, '默认分类', 1, 0, 0),
(2, '官方板块', 1, 1, 0);

delete from `thinkox_menu` where  `url` like '%Forum%';
INSERT INTO `thinkox_menu` (`title`, `pid`, `sort`, `url`, `hide`, `tip`, `group`, `is_dev`) VALUES
( '论坛', 0, 22, 'Forum/index', 0, '', '', 0);
set @tmp_id=0;
select @tmp_id:= id from `thinkox_menu` where title = '论坛';

INSERT INTO `thinkox_menu` ( `title`, `pid`, `sort`, `url`, `hide`, `tip`, `group`, `is_dev`) VALUES
( '板块管理', @tmp_id, 1, 'Forum/forum', 0, '', '板块', 0),
( '帖子管理', @tmp_id, 3, 'Forum/post', 0, '', '帖子', 0),
( '编辑／创建板块', @tmp_id, 0, 'Forum/editForum', 1, '', '', 0),
( '编辑帖子', @tmp_id, 0, 'Forum/editPost', 1, '', '', 0),
( '排序', @tmp_id, 0, 'Forum/sortForum', 0, '', '板块', 0),
( '新增/编辑回复', @tmp_id, 0, 'Forum/editReply',1, '', '', 0),
( '板块回收站', @tmp_id, 2, 'Forum/forumTrash', 0, '', '板块', 0),
( '帖子回收站', @tmp_id, 4, 'Forum/postTrash', 0, '', '帖子', 0),
( '回复回收站', @tmp_id, 6, 'Forum/replyTrash', 0, '', '回复', 0),
( '回复管理', @tmp_id, 6, 'Forum/reply', 0, '', '回复', 0),
( '论坛设置', @tmp_id, 10, 'Forum/config', 0, '', '设置', 0),
( '新增/编辑分类', @tmp_id, 0, 'Forum/addType', 1, '', '', 0),
( '设置分类状态', @tmp_id, 0, 'Forum/setTypeStatus', 1, '', '', 0),
( '分类管理', @tmp_id, 0, 'Forum/type', 0, '分类管理', '分类管理', 0);

ALTER TABLE  `thinkox_forum` ADD  `last_reply_time` INT NOT NULL;


INSERT INTO `thinkox_config` ( `name`, `type`, `title`, `group`, `extra`, `remark`, `create_time`, `update_time`, `status`, `value`, `sort`) VALUES
( 'DEFUALT_HOME_URL', 1, '默认首页Url', 1, '', '支持形如weibo/index/index的ThinkPhp路由写法，支持普通的url写法，不填则显示默认聚合首页', 1417509438, 1417509501, 1, 'Weibo/index/index', 0);
ALTER TABLE  `thinkox_auth_group` CHANGE  `rules`  `rules` TEXT CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT  '' COMMENT  '用户组拥有的规则id，多个规则 , 隔开';
