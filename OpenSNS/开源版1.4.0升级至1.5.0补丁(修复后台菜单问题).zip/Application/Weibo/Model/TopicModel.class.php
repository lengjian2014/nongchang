<?php
/**
 * 话题模型
 * 没有话题的情况下添加话题
 * 有话题的时候在输入#的时候弹出
 * @author quick
 *
 */
namespace Weibo\Model;

use Think\Model;

class TopicModel extends Model{
	
}